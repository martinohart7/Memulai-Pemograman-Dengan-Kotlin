/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah kode yang sudah ada.
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */
fun main() {

    // TODO 1
    val vehicle = mapOf<String, String>(
            "type" to "Motorcycle",
            "maxSpeed" to "230Km/s",
            "maxTank" to "10Ltr"
    )

    // TODO 2

    val type = "Motorcycle"
    val maxSpeed = "230Km/s"
    val maxTank = "10Ltr"


    // TODO 3
    println("Vehicle")
    print("Type: ")
    println(type)
    print("Maximal Speed: ")
    println(maxSpeed)
    print("Maximal Tank: ")
    println(maxTank)

}